RUTA_ARCHIVO = "C:\Users\aquin\Downloads\listaAlumnosC3 (1).txt"


try
    #abrimos el archivo en modo lectura
  archivo=open(RUTA_ARCHIVO, "r" , encoding="ut

